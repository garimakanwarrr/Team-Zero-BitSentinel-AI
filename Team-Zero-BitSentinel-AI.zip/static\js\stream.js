/**
 * BitSentinel AI - Real-Time Telemetry & Transaction Stream Manager
 * Handles simulated live mempool transactions, audio synthesis telemetry, and threat injections.
 */

class TransactionStreamManager {
  constructor() {
    this.tableBody = document.getElementById('txStreamTableBody');
    this.streamPaused = false;
    this.streamSpeed = 2500; // ms interval
    this.timer = null;
    this.transactions = [];
    this.soundEnabled = true;
    this.audioCtx = null;
    
    this.filterRisk = 'ALL';
    this.searchQuery = '';
    
    this.initAudio();
    this.bindControls();
    this.startStreaming();
  }

  initAudio() {
    try {
      const AudioContext = window.AudioContext || window.webkitAudioContext;
      this.audioCtx = new AudioContext();
    } catch (e) {
      console.warn('Web Audio not supported', e);
    }
  }

  playBeep(isAlert = false) {
    if (!this.soundEnabled || !this.audioCtx) return;
    try {
      if (this.audioCtx.state === 'suspended') {
        this.audioCtx.resume();
      }
      const osc = this.audioCtx.createOscillator();
      const gain = this.audioCtx.createGain();
      osc.connect(gain);
      gain.connect(this.audioCtx.destination);

      if (isAlert) {
        osc.frequency.setValueAtTime(880, this.audioCtx.currentTime); // High pitch alarm
        osc.type = 'sawtooth';
        gain.gain.setValueAtTime(0.08, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.18);
        osc.start();
        osc.stop(this.audioCtx.currentTime + 0.18);
      } else {
        osc.frequency.setValueAtTime(440, this.audioCtx.currentTime); // Soft tick
        osc.type = 'sine';
        gain.gain.setValueAtTime(0.02, this.audioCtx.currentTime);
        gain.gain.exponentialRampToValueAtTime(0.001, this.audioCtx.currentTime + 0.06);
        osc.start();
        osc.stop(this.audioCtx.currentTime + 0.06);
      }
    } catch (err) {}
  }

  bindControls() {
    // Sound Toggle
    const soundBtn = document.getElementById('btnToggleSound');
    if (soundBtn) {
      soundBtn.addEventListener('click', () => {
        this.soundEnabled = !this.soundEnabled;
        soundBtn.innerHTML = this.soundEnabled 
          ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><path d="M19.07 4.93a10 10 0 0 1 0 14.14M15.54 8.46a5 5 0 0 1 0 7.07"></path></svg> AUDIO: ON`
          : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="11 5 6 9 2 9 2 15 6 15 11 19 11 5"></polygon><line x1="23" y1="9" x2="17" y2="15"></line><line x1="17" y1="9" x2="23" y2="15"></line></svg> AUDIO: MUTED`;
      });
    }

    // Stream Pause / Play
    const pauseBtn = document.getElementById('btnPauseStream');
    if (pauseBtn) {
      pauseBtn.addEventListener('click', () => {
        this.streamPaused = !this.streamPaused;
        pauseBtn.innerHTML = this.streamPaused
          ? `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><polygon points="5 3 19 12 5 21 5 3"></polygon></svg> RESUME FEED`
          : `<svg width="14" height="14" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2"><rect x="6" y="4" width="4" height="16"></rect><rect x="14" y="4" width="4" height="16"></rect></svg> PAUSE FEED`;
      });
    }

    // Speed Selector
    const speedSelect = document.getElementById('selectStreamSpeed');
    if (speedSelect) {
      speedSelect.addEventListener('change', (e) => {
        this.streamSpeed = parseInt(e.target.value);
        this.restartStreamInterval();
      });
    }

    // Risk Filter
    const riskFilter = document.getElementById('filterRiskSelect');
    if (riskFilter) {
      riskFilter.addEventListener('change', (e) => {
        this.filterRisk = e.target.value;
        this.renderTable();
      });
    }

    // Search Input
    const searchInput = document.getElementById('inputSearchTx');
    if (searchInput) {
      searchInput.addEventListener('input', (e) => {
        this.searchQuery = e.target.value.toLowerCase().trim();
        this.renderTable();
      });
    }

    // Injection Buttons
    document.querySelectorAll('.btn-inject-threat').forEach(btn => {
      btn.addEventListener('click', () => {
        const type = btn.getAttribute('data-type');
        this.injectAnomaly(type);
      });
    });
  }

  restartStreamInterval() {
    if (this.timer) clearInterval(this.timer);
    this.timer = setInterval(() => {
      if (!this.streamPaused) {
        this.fetchNextTransaction();
      }
    }, this.streamSpeed);
  }

  async fetchNextTransaction(forcedType = null) {
    try {
      const url = forcedType 
        ? `/api/telemetry/single-stream?forced_type=${forcedType}`
        : `/api/telemetry/single-stream`;
      const res = await fetch(url);
      const tx = await res.json();
      
      this.transactions.unshift(tx);
      if (this.transactions.length > 50) this.transactions.pop();

      const isAlert = tx.risk_level === 'CRITICAL' || tx.risk_level === 'HIGH';
      this.playBeep(isAlert);

      this.renderTable(true);
    } catch (err) {
      console.error('Error fetching stream tx', err);
    }
  }

  injectAnomaly(type) {
    this.fetchNextTransaction(type);
  }

  renderTable(highlightFirst = false) {
    if (!this.tableBody) return;

    const filtered = this.transactions.filter(tx => {
      const matchRisk = this.filterRisk === 'ALL' || tx.risk_level === this.filterRisk;
      const matchSearch = !this.searchQuery 
        || tx.tx_hash.toLowerCase().includes(this.searchQuery)
        || tx.source_address.toLowerCase().includes(this.searchQuery)
        || tx.dest_address.toLowerCase().includes(this.searchQuery)
        || (tx.anomaly_tags && tx.anomaly_tags.some(t => t.toLowerCase().includes(this.searchQuery)));
      return matchRisk && matchSearch;
    });

    this.tableBody.innerHTML = filtered.map((tx, idx) => {
      const isNew = highlightFirst && idx === 0;
      const shortHash = `${tx.tx_hash.substring(0, 8)}...${tx.tx_hash.substring(tx.tx_hash.length - 6)}`;
      const shortSource = `${tx.source_address.substring(0, 6)}...${tx.source_address.substring(tx.source_address.length - 4)}`;
      const shortDest = `${tx.dest_address.substring(0, 6)}...${tx.dest_address.substring(tx.dest_address.length - 4)}`;

      return `
        <tr class="${isNew ? 'new-row' : ''}" onclick="window.streamManager.openTxModal('${tx.tx_hash}')">
          <td><span style="color: #64748b;">${tx.timestamp}</span></td>
          <td><a class="hash-link" href="javascript:void(0)">${shortHash}</a></td>
          <td><span class="address-tag" title="${tx.source_address}">${shortSource}</span></td>
          <td><span class="address-tag" title="${tx.dest_address}">${shortDest}</span></td>
          <td style="color: var(--btc-gold); font-weight: 700;">${tx.amount_btc.toFixed(4)} BTC</td>
          <td>$${(tx.amount_usd || (tx.amount_btc * 68450)).toLocaleString()}</td>
          <td>${tx.fee_sat_vb} sat/vB</td>
          <td><span class="risk-badge ${tx.risk_level.toLowerCase()}">${tx.risk_level} (${tx.risk_score})</span></td>
          <td><span style="color: #cbd5e1; font-size: 0.72rem;">${tx.anomaly_tags ? tx.anomaly_tags[0] : 'Standard'}</span></td>
        </tr>
      `;
    }).join('');
  }

  openTxModal(hash) {
    const tx = this.transactions.find(t => t.tx_hash === hash);
    if (!tx) return;

    const modal = document.getElementById('txDetailModal');
    if (!modal) return;

    document.getElementById('modalTxHash').textContent = tx.tx_hash;
    document.getElementById('modalSource').textContent = tx.source_address;
    document.getElementById('modalDest').textContent = tx.dest_address;
    document.getElementById('modalAmountBtc').textContent = `${tx.amount_btc.toFixed(4)} BTC`;
    document.getElementById('modalAmountUsd').textContent = `$${(tx.amount_usd || (tx.amount_btc * 68450)).toLocaleString()} USD`;
    document.getElementById('modalFee').textContent = `${tx.fee_sat_vb} sat/vB`;
    document.getElementById('modalRiskScore').textContent = `${tx.risk_score} / 100`;
    document.getElementById('modalRiskBadge').className = `risk-badge ${tx.risk_level.toLowerCase()}`;
    document.getElementById('modalRiskBadge').textContent = tx.risk_level;
    document.getElementById('modalTags').innerHTML = (tx.anomaly_tags || []).map(tag => 
      `<span class="panel-title-badge">${tag}</span>`
    ).join(' ');
    document.getElementById('modalExplanation').textContent = tx.explanation || 'No anomalies detected.';
    document.getElementById('modalMitigation').textContent = tx.mitigation_action || 'Proceed with normal validation.';

    modal.classList.add('active');
  }

  startStreaming() {
    // Initial batch load
    fetch('/api/telemetry/live-stream')
      .then(res => res.json())
      .then(data => {
        this.transactions = data.transactions || [];
        this.renderTable();
        this.restartStreamInterval();
      })
      .catch(err => console.error(err));
  }
}

window.TransactionStreamManager = TransactionStreamManager;
