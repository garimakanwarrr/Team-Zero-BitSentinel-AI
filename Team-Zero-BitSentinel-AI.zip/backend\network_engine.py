"""
BitSentinel AI - Network Graph Engine
Constructs and provides interactive node-link network topologies for Bitcoin transaction flows,
UTXO peeling chains, and mixer relationships.
"""

import random
import hashlib

def generate_network_graph(mode="full"):
    """
    Returns an engineered graph structure with nodes (wallets/entities) 
    and links (directed Bitcoin transactions).
    """

    # Core nodes
    nodes = [
        # Sanctioned & High Risk
        {"id": "node_darknet_hydra", "label": "Hydra Relaying Node", "address": "bc1qa5wkgaew2dkv56kfvj49j0av5nml45x9ek9hz6", "type": "SANCTIONED", "risk": "CRITICAL", "balance": 142.85, "tx_count": 892},
        {"id": "node_conti_ransom", "label": "Conti Ransomware Vault", "address": "1LdRcdxfbSnmCYYNdeYpUnztiYzVfBEQeC", "type": "SANCTIONED", "risk": "CRITICAL", "balance": 68.40, "tx_count": 314},
        {"id": "node_lazarus", "label": "Lazarus OFAC Cluster", "address": "3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5", "type": "SANCTIONED", "risk": "CRITICAL", "balance": 520.12, "tx_count": 1205},
        
        # Obfuscation / Mixer Hubs
        {"id": "node_mixer_wasabi", "label": "Wasabi CoinJoin Pool", "address": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", "type": "MIXER", "risk": "HIGH", "balance": 89.15, "tx_count": 4830},
        {"id": "node_mixer_chip", "label": "ChipMixer Obfuscator", "address": "1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "type": "MIXER", "risk": "HIGH", "balance": 45.30, "tx_count": 2109},

        # Peeling Chain Intermediary Hops
        {"id": "node_peel_hop1", "label": "Peel UTXO Hop #1", "address": "bc1q78p2e8e9r93m5x5f6s7a8d9f0g1h2j3k4l5z1", "type": "PEELING_HOP", "risk": "HIGH", "balance": 18.20, "tx_count": 12},
        {"id": "node_peel_hop2", "label": "Peel UTXO Hop #2", "address": "bc1q99k8j7h6g5f4d3s2a1z0x9c8v7b6n5m4l3k2", "type": "PEELING_HOP", "risk": "HIGH", "balance": 16.35, "tx_count": 9},
        {"id": "node_peel_hop3", "label": "Peel UTXO Hop #3", "address": "bc1q55m4n3b2v1c0x9z8a7s6d5f4g3h2j1k0l9p8", "type": "PEELING_HOP", "risk": "MEDIUM", "balance": 14.80, "tx_count": 7},
        {"id": "node_peel_hop4", "label": "Peel UTXO Hop #4", "address": "bc1q11z2x3c4v5b6n7m8a9s0d1f2g3h4j5k6l7m8", "type": "PEELING_HOP", "risk": "MEDIUM", "balance": 13.10, "tx_count": 5},

        # Whale Wallets
        {"id": "node_whale_alpha", "label": "Whale Cold Vault Alpha", "address": "1P5ZEDWTKTFGxQjZphgWPQUpe554WKDfHQ", "type": "WHALE", "risk": "LOW", "balance": 12450.0, "tx_count": 145},
        {"id": "node_whale_beta", "label": "Satoshi Era Legacy Dormant", "address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa", "type": "WHALE", "risk": "LOW", "balance": 50.0, "tx_count": 3},

        # Regulated Institutional Exchanges
        {"id": "node_binance_vault", "label": "Binance Cold Storage", "address": "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy", "type": "EXCHANGE", "risk": "LOW", "balance": 24890.5, "tx_count": 68900},
        {"id": "node_coinbase_hot", "label": "Coinbase Prime Settlement", "address": "bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h", "type": "EXCHANGE", "risk": "LOW", "balance": 18450.2, "tx_count": 52140},
        {"id": "node_kraken_dep", "label": "Kraken Gateway Pool", "address": "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo", "type": "EXCHANGE", "risk": "LOW", "balance": 8920.4, "tx_count": 31200},

        # Retail & Smurfing Wallets
        {"id": "node_smurf_1", "label": "Mule Smurf Address #1", "address": "bc1q88a9s7d6f5g4h3j2k1l0z9x8c7v6b5n4m3q1", "type": "MULE", "risk": "HIGH", "balance": 0.49, "tx_count": 28},
        {"id": "node_smurf_2", "label": "Mule Smurf Address #2", "address": "bc1q77z6x5c4v3b2n1m0a9s8d7f6g5h4j3k2l1w2", "type": "MULE", "risk": "HIGH", "balance": 0.48, "tx_count": 31},
        {"id": "node_peer_alice", "label": "Retail Merchant Alice", "address": "1CounterpartyXXXXXXXXXXXXXXXUWLpVr", "type": "USER", "risk": "LOW", "balance": 1.45, "tx_count": 42},
        {"id": "node_peer_bob", "label": "Retail Consumer Bob", "address": "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq", "type": "USER", "risk": "LOW", "balance": 0.75, "tx_count": 18}
    ]

    # Directed Transaction Links (UTXO flow)
    links = [
        # Ransomware -> Peeling Chain Flow
        {"source": "node_conti_ransom", "target": "node_peel_hop1", "amount": 20.0, "tx_hash": "e8a1f4b23891c62047d9c1584b2c124806a7df75", "risk": "CRITICAL", "type": "Ransom Transfer"},
        {"source": "node_peel_hop1", "target": "node_peel_hop2", "amount": 18.2, "tx_hash": "b2c93847a165f492801e7456d3c0182479e5fa41", "risk": "HIGH", "type": "Peel Change (91%)"},
        {"source": "node_peel_hop1", "target": "node_smurf_1", "amount": 1.8, "tx_hash": "37a91c84b502d6193850ea17f2c84019a3b6d215", "risk": "HIGH", "type": "Peel Payout"},
        
        {"source": "node_peel_hop2", "target": "node_peel_hop3", "amount": 16.35, "tx_hash": "7489a2b1c3d4e5f60718293a4b5c6d7e8f901234", "risk": "HIGH", "type": "Peel Change (90%)"},
        {"source": "node_peel_hop2", "target": "node_smurf_2", "amount": 1.85, "tx_hash": "56f4e3d2c1b0a9876543210fedcba98765432109", "risk": "HIGH", "type": "Peel Payout"},

        {"source": "node_peel_hop3", "target": "node_peel_hop4", "amount": 14.8, "tx_hash": "890abcdef1234567890abcdef1234567890abcdef", "risk": "MEDIUM", "type": "Peel Change (90%)"},
        {"source": "node_peel_hop3", "target": "node_mixer_wasabi", "amount": 1.55, "tx_hash": "11223344556677889900aabbccddeeff00112233", "risk": "CRITICAL", "type": "Mixer Inflow"},

        # Lazarus / Hydra -> ChipMixer -> Exfiltration
        {"source": "node_darknet_hydra", "target": "node_mixer_chip", "amount": 42.0, "tx_hash": "aa11bb22cc33dd44ee55ff660011223344556677", "risk": "CRITICAL", "type": "Illicit Inflow"},
        {"source": "node_lazarus", "target": "node_mixer_chip", "amount": 65.5, "tx_hash": "ffeeddccbbaa99887766554433221100ffeeddcc", "risk": "CRITICAL", "type": "State-Sponsored Launder"},

        # Mixer Outflows into exchanges
        {"source": "node_mixer_chip", "target": "node_smurf_1", "amount": 8.5, "tx_hash": "1234567890abcdef1234567890abcdef12345678", "risk": "HIGH", "type": "Mixed Outflow"},
        {"source": "node_mixer_wasabi", "target": "node_smurf_2", "amount": 12.0, "tx_hash": "fedcba9876543210fedcba9876543210fedcba98", "risk": "HIGH", "type": "Mixed Outflow"},

        # Smurfs depositing into exchanges (Structuring)
        {"source": "node_smurf_1", "target": "node_binance_vault", "amount": 0.49, "tx_hash": "3344556677889900aabbccddeeff001122334455", "risk": "HIGH", "type": "Structured Deposit"},
        {"source": "node_smurf_2", "target": "node_kraken_dep", "amount": 0.48, "tx_hash": "556677889900aabbccddeeff0011223344556677", "risk": "HIGH", "type": "Structured Deposit"},

        # Legitimate Whale & Retail Flows
        {"source": "node_whale_alpha", "target": "node_coinbase_hot", "amount": 150.0, "tx_hash": "99887766554433221100ffeeddccbbaa99887766", "risk": "LOW", "type": "Institutional Liquidity"},
        {"source": "node_coinbase_hot", "target": "node_peer_alice", "amount": 1.5, "tx_hash": "4433221100ffeeddccbbaa998877665544332211", "risk": "LOW", "type": "Retail Withdrawal"},
        {"source": "node_peer_alice", "target": "node_peer_bob", "amount": 0.65, "tx_hash": "00112233445566778899aabbccddeeff00112233", "risk": "LOW", "type": "P2P Payment"},
        {"source": "node_binance_vault", "target": "node_kraken_dep", "amount": 85.0, "tx_hash": "6677889900aabbccddeeff001122334455667788", "risk": "LOW", "type": "Arbitrage Settlement"}
    ]

    return {"nodes": nodes, "links": links, "total_nodes": len(nodes), "total_links": len(links)}

def trace_address_subgraph(address: str):
    """
    Traces incoming and outgoing transactions for a specific address.
    """
    full_graph = generate_network_graph()
    matching_node = next((n for n in full_graph["nodes"] if n["address"].lower() == address.lower() or n["id"] == address), None)
    
    if not matching_node:
        # Create a mock traced node if not found
        node_id = f"node_traced_{address[:8]}"
        matching_node = {
            "id": node_id,
            "label": f"Traced: {address[:10]}...",
            "address": address,
            "type": "USER",
            "risk": "MEDIUM",
            "balance": round(random.uniform(0.1, 8.5), 4),
            "tx_count": random.randint(3, 40)
        }
        full_graph["nodes"].append(matching_node)

    # Filter connected links and nodes
    connected_links = [
        link for link in full_graph["links"]
        if link["source"] == matching_node["id"] or link["target"] == matching_node["id"]
    ]

    connected_node_ids = set([matching_node["id"]])
    for link in connected_links:
        connected_node_ids.add(link["source"])
        connected_node_ids.add(link["target"])

    connected_nodes = [n for n in full_graph["nodes"] if n["id"] in connected_node_ids]

    return {
        "root_address": address,
        "nodes": connected_nodes,
        "links": connected_links,
        "hop_depth": 2
    }
