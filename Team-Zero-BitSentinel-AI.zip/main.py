"""
BitSentinel AI - Full Stack FastAPI Application
Hackathon Project: AI Powered Monitoring & Analysis of Bitcoin Transaction Traffic
Team ZERO | Team Leader: Garima Kanwar & Members
"""

import os
import io
import json
import sqlite3
import pandas as pd
from typing import Optional
from datetime import datetime
from fastapi import FastAPI, UploadFile, File, Form, HTTPException, Depends, Request
from fastapi.responses import HTMLResponse, JSONResponse, FileResponse
from fastapi.staticfiles import StaticFiles
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel

from backend.database import init_db, get_db, hash_password
from backend.ml_engine import detector
from backend.telemetry import (
    get_telemetry_snapshot,
    get_chart_series,
    generate_single_transaction,
    SAMPLE_POOLS
)
from backend.network_engine import generate_network_graph, trace_address_subgraph

# Initialize Database on startup
init_db()

app = FastAPI(
    title="BitSentinel AI",
    description="AI Powered Monitoring & Analysis of Bitcoin Transaction Traffic - Team ZERO",
    version="2.0.0"
)

# CORS
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Mount Static Files
BASE_DIR = os.path.dirname(os.path.abspath(__file__))
STATIC_DIR = os.path.join(BASE_DIR, "static")
TEMPLATES_DIR = os.path.join(BASE_DIR, "templates")

app.mount("/static", StaticFiles(directory=STATIC_DIR), name="static")

# Schemas
class RegisterRequest(BaseModel):
    username: str
    email: str
    password: str
    organization: str
    role: Optional[str] = "Security Analyst"

class LoginRequest(BaseModel):
    username: str
    password: str

class CustomAnalyzeRequest(BaseModel):
    tx_hash: Optional[str] = None
    source_address: str
    dest_address: str
    amount_btc: float
    fee_sat_vb: Optional[float] = 25.0
    inputs_count: Optional[int] = 1
    outputs_count: Optional[int] = 2
    change_ratio: Optional[float] = 0.90
    equal_outputs: Optional[bool] = False
    forced_anomaly: Optional[str] = None

# --- WEB UI ROUTE ---
@app.get("/", response_class=HTMLResponse)
async def serve_index():
    index_file = os.path.join(TEMPLATES_DIR, "index.html")
    if os.path.exists(index_file):
        with open(index_file, "r", encoding="utf-8") as f:
            return HTMLResponse(content=f.read())
    return HTMLResponse(content="<h1>BitSentinel AI System Initializing...</h1>")

# --- AUTH ROUTES ---
@app.post("/api/auth/register")
async def register_user(req: RegisterRequest):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT id FROM users WHERE username = ? OR email = ?", (req.username, req.email))
    if cursor.fetchone():
        conn.close()
        raise HTTPException(status_code=400, detail="Username or email already exists in system.")

    pwd_hash = hash_password(req.password)
    now = datetime.utcnow().isoformat()
    cursor.execute("""
    INSERT INTO users (username, email, password_hash, organization, role, created_at)
    VALUES (?, ?, ?, ?, ?, ?)
    """, (req.username, req.email, pwd_hash, req.organization, req.role or "Security Analyst", now))
    conn.commit()
    user_id = cursor.lastrowid
    conn.close()

    return {
        "status": "success",
        "message": "User registered successfully",
        "user": {
            "id": user_id,
            "username": req.username,
            "email": req.email,
            "organization": req.organization,
            "role": req.role
        }
    }

@app.post("/api/auth/login")
async def login_user(req: LoginRequest):
    conn = get_db()
    cursor = conn.cursor()
    pwd_hash = hash_password(req.password)
    cursor.execute("SELECT id, username, email, organization, role FROM users WHERE username = ? AND password_hash = ?", (req.username, pwd_hash))
    user = cursor.fetchone()
    conn.close()

    if not user:
        raise HTTPException(status_code=401, detail="Invalid username or password credentials.")

    return {
        "status": "success",
        "message": "Authentication successful",
        "user": {
            "id": user["id"],
            "username": user["username"],
            "email": user["email"],
            "organization": user["organization"],
            "role": user["role"]
        }
    }

# --- TELEMETRY & LIVE STREAM ---
@app.get("/api/telemetry/stats")
async def get_stats():
    return get_telemetry_snapshot()

@app.get("/api/telemetry/charts")
async def get_charts():
    return get_chart_series()

@app.get("/api/telemetry/live-stream")
async def get_live_stream_batch():
    batch = [generate_single_transaction() for _ in range(8)]
    return {"transactions": batch}

@app.get("/api/telemetry/single-stream")
async def get_single_transaction(forced_type: Optional[str] = None):
    tx = generate_single_transaction(forced_type=forced_type)
    return tx

# --- AI ANOMALY ENGINE ---
@app.post("/api/ai/analyze-transaction")
async def analyze_custom_transaction(req: CustomAnalyzeRequest):
    tx_dict = req.model_dump()
    if not tx_dict.get("tx_hash"):
        import hashlib, time
        tx_dict["tx_hash"] = hashlib.sha256(f"custom_{time.time()}".encode()).hexdigest()
    analysis = detector.analyze_transaction(tx_dict)
    return {
        "transaction": tx_dict,
        "analysis": analysis
    }

@app.get("/api/ai/preset-scenarios")
async def get_preset_scenarios():
    return {
        "scenarios": [
            {
                "id": "scenario_peel",
                "title": "Conti Ransomware Peeling Chain",
                "description": "High-frequency asymmetric change output stripping funds through multi-hop UTXO succession.",
                "payload": {
                    "source_address": "1LdRcdxfbSnmCYYNdeYpUnztiYzVfBEQeC",
                    "dest_address": "bc1q78p2e8e9r93m5x5f6s7a8d9f0g1h2j3k4l5z1",
                    "amount_btc": 14.85,
                    "fee_sat_vb": 84.0,
                    "inputs_count": 1,
                    "outputs_count": 2,
                    "change_ratio": 0.94,
                    "forced_anomaly": "PEELING_CHAIN"
                }
            },
            {
                "id": "scenario_mixer",
                "title": "Wasabi CoinJoin Obfuscation Cluster",
                "description": "Equalized multi-party inputs and outputs obfuscating transaction graph provenance.",
                "payload": {
                    "source_address": "bc1qa5wkgaew2dkv56kfvj49j0av5nml45x9ek9hz6",
                    "dest_address": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh",
                    "amount_btc": 8.50,
                    "fee_sat_vb": 128.0,
                    "inputs_count": 6,
                    "outputs_count": 6,
                    "equal_outputs": True,
                    "forced_anomaly": "MIXER"
                }
            },
            {
                "id": "scenario_smurfing",
                "title": "AML Structuring Threshold ($9,850)",
                "description": "Transaction strategically structured below the 0.15 BTC / $10k FinCEN AML threshold.",
                "payload": {
                    "source_address": "bc1q88a9s7d6f5g4h3j2k1l0z9x8c7v6b5n4m3q1",
                    "dest_address": "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo",
                    "amount_btc": 0.1438,
                    "fee_sat_vb": 36.0,
                    "inputs_count": 1,
                    "outputs_count": 2,
                    "change_ratio": 0.75,
                    "forced_anomaly": "STRUCTURING"
                }
            },
            {
                "id": "scenario_dust",
                "title": "Micro Dust De-anonymization Attack",
                "description": "Tiny fraction of Satoshi distributed across thousands of addresses to trace unspent outputs.",
                "payload": {
                    "source_address": "1CounterpartyXXXXXXXXXXXXXXXUWLpVr",
                    "dest_address": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa",
                    "amount_btc": 0.00008,
                    "fee_sat_vb": 19.0,
                    "inputs_count": 1,
                    "outputs_count": 20,
                    "change_ratio": 0.0,
                    "forced_anomaly": "DUST"
                }
            },
            {
                "id": "scenario_legit",
                "title": "Exchange Prime Liquidity Transfer",
                "description": "Normal high-volume verified institutional settlement between Coinbase and Binance vaults.",
                "payload": {
                    "source_address": "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy",
                    "dest_address": "bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h",
                    "amount_btc": 35.0,
                    "fee_sat_vb": 22.0,
                    "inputs_count": 2,
                    "outputs_count": 2,
                    "change_ratio": 0.60
                }
            }
        ]
    }

# --- NETWORK GRAPH ROUTES ---
@app.get("/api/network/graph-data")
async def get_graph():
    return generate_network_graph()

@app.get("/api/network/trace-address/{address}")
async def trace_address(address: str):
    return trace_address_subgraph(address)

# --- ADMIN PORTAL & DATASET UPLOAD / ANALYSIS ---
@app.post("/api/admin/upload-dataset")
async def upload_and_analyze_dataset(
    file: UploadFile = File(...),
    user_id: int = Form(1)
):
    """
    Receives CSV or JSON dataset from user or organization,
    runs automated ML anomaly scoring across every transaction row,
    and stores records in SQLite with full statistical risk reporting.
    """
    filename = file.filename
    content = await file.read()

    try:
        if filename.endswith(".csv"):
            df = pd.read_csv(io.BytesIO(content))
            records = df.to_dict(orient="records")
            file_type = "CSV"
        elif filename.endswith(".json"):
            records = json.loads(content.decode("utf-8"))
            if isinstance(records, dict) and "transactions" in records:
                records = records["transactions"]
            file_type = "JSON"
        else:
            raise HTTPException(status_code=400, detail="Unsupported file format. Please upload .csv or .json files.")
    except Exception as e:
        raise HTTPException(status_code=400, detail=f"Failed to parse file: {str(e)}")

    if not records:
        raise HTTPException(status_code=400, detail="Uploaded dataset contains no records.")

    conn = get_db()
    cursor = conn.cursor()

    anomalies_detected = 0
    total_risk_score = 0.0
    high_risk_count = 0
    analyzed_rows = []

    now_iso = datetime.utcnow().isoformat()

    # Pre-insert dataset metadata
    cursor.execute("""
    INSERT INTO datasets (user_id, filename, file_type, row_count, anomalies_detected, high_risk_ratio, status, uploaded_at, analysis_summary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, filename, file_type, len(records), 0, 0.0, "Processing", now_iso, "{}"))
    dataset_id = cursor.lastrowid

    import hashlib, time

    for idx, row in enumerate(records):
        tx_hash = str(row.get("tx_hash") or hashlib.sha256(f"row_{dataset_id}_{idx}_{time.time()}".encode()).hexdigest())
        source = str(row.get("source_address", f"bc1q_source_mock_{idx}"))
        dest = str(row.get("dest_address", f"bc1q_dest_mock_{idx}"))
        
        try:
            amt_btc = float(row.get("amount_btc", 0.05))
        except:
            amt_btc = 0.05

        try:
            fee_sat = float(row.get("fee_sat_vb", 25.0))
        except:
            fee_sat = 25.0

        try:
            in_cnt = int(row.get("inputs_count", 1))
        except:
            in_cnt = 1

        try:
            out_cnt = int(row.get("outputs_count", 2))
        except:
            out_cnt = 2

        try:
            change_rat = float(row.get("change_ratio", 0.85))
        except:
            change_rat = 0.85

        equal_outs = bool(row.get("equal_outputs", False))

        tx_payload = {
            "tx_hash": tx_hash,
            "source_address": source,
            "dest_address": dest,
            "amount_btc": amt_btc,
            "fee_sat_vb": fee_sat,
            "inputs_count": in_cnt,
            "outputs_count": out_cnt,
            "change_ratio": change_rat,
            "equal_outputs": equal_outs
        }

        # Run AI Anomaly analysis
        eval_res = detector.analyze_transaction(tx_payload)
        risk_score = eval_res["risk_score"]
        risk_lvl = eval_res["risk_level"]
        tags_str = ", ".join(eval_res["anomaly_tags"])
        explanation = eval_res["explanation"]

        total_risk_score += risk_score
        if risk_lvl in ["HIGH", "CRITICAL"]:
            anomalies_detected += 1
            high_risk_count += 1
        elif risk_lvl == "MEDIUM":
            anomalies_detected += 1

        cursor.execute("""
        INSERT INTO dataset_transactions (
            dataset_id, tx_hash, source_address, dest_address, amount_btc, 
            amount_usd, fee_sat_vb, timestamp, risk_score, risk_level, 
            anomaly_tags, explanation
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            dataset_id, tx_hash, source, dest, amt_btc, 
            eval_res["amount_usd"], fee_sat, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            risk_score, risk_lvl, tags_str, explanation
        ))

        analyzed_rows.append({
            "tx_hash": tx_hash,
            "source_address": source,
            "dest_address": dest,
            "amount_btc": amt_btc,
            "amount_usd": eval_res["amount_usd"],
            "fee_sat_vb": fee_sat,
            "risk_score": risk_score,
            "risk_level": risk_lvl,
            "anomaly_tags": eval_res["anomaly_tags"],
            "explanation": explanation,
            "mitigation_action": eval_res["mitigation_action"]
        })

    row_count = len(records)
    avg_risk = round(total_risk_score / row_count, 1) if row_count > 0 else 0.0
    high_risk_ratio = round((high_risk_count / row_count) * 100, 1) if row_count > 0 else 0.0

    summary_data = {
        "total_records": row_count,
        "anomalies_count": anomalies_detected,
        "high_risk_count": high_risk_count,
        "average_risk_score": avg_risk,
        "high_risk_ratio_pct": high_risk_ratio,
        "scan_engine": "BitSentinel Multi-Vector Heuristic & Isolation Ensemble v3.4",
        "recommended_action": "Freeze high-risk outputs and forward report to AML compliance" if high_risk_count > 0 else "All records within acceptable risk variance."
    }

    cursor.execute("""
    UPDATE datasets 
    SET anomalies_detected = ?, high_risk_ratio = ?, status = 'Completed', analysis_summary = ?
    WHERE id = ?
    """, (anomalies_detected, high_risk_ratio, json.dumps(summary_data), dataset_id))

    conn.commit()
    conn.close()

    return {
        "status": "success",
        "dataset_id": dataset_id,
        "filename": filename,
        "summary": summary_data,
        "transactions_preview": analyzed_rows[:15],
        "total_processed": row_count
    }

@app.get("/api/admin/datasets")
async def list_datasets(user_id: Optional[int] = None):
    conn = get_db()
    cursor = conn.cursor()
    if user_id:
        cursor.execute("SELECT * FROM datasets WHERE user_id = ? ORDER BY id DESC", (user_id,))
    else:
        cursor.execute("SELECT * FROM datasets ORDER BY id DESC")
    rows = [dict(row) for row in cursor.fetchall()]
    conn.close()

    for r in rows:
        if r.get("analysis_summary"):
            try:
                r["analysis_summary"] = json.loads(r["analysis_summary"])
            except:
                pass
    return {"datasets": rows}

@app.get("/api/admin/datasets/{dataset_id}")
async def get_dataset_detail(dataset_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM datasets WHERE id = ?", (dataset_id,))
    dataset = cursor.fetchone()
    if not dataset:
        conn.close()
        raise HTTPException(status_code=404, detail="Dataset not found")

    d_dict = dict(dataset)
    if d_dict.get("analysis_summary"):
        try:
            d_dict["analysis_summary"] = json.loads(d_dict["analysis_summary"])
        except:
            pass

    cursor.execute("SELECT * FROM dataset_transactions WHERE dataset_id = ? ORDER BY risk_score DESC", (dataset_id,))
    txs = [dict(tx) for tx in cursor.fetchall()]
    conn.close()

    return {
        "dataset": d_dict,
        "transactions": txs
    }

@app.get("/api/admin/datasets/{dataset_id}/export")
async def export_audit_report(dataset_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("SELECT * FROM datasets WHERE id = ?", (dataset_id,))
    dataset = cursor.fetchone()
    if not dataset:
        conn.close()
        raise HTTPException(status_code=404, detail="Dataset not found")

    cursor.execute("SELECT * FROM dataset_transactions WHERE dataset_id = ? ORDER BY risk_score DESC", (dataset_id,))
    txs = [dict(tx) for tx in cursor.fetchall()]
    conn.close()

    report = {
        "audit_title": "BitSentinel AI - Forensic Bitcoin Transaction Risk Audit",
        "hackathon_metadata": {
            "title": "AI Powered Monitoring & Analysis of Bitcoin Transaction Traffic",
            "team_name": "Team ZERO",
            # "team_leader": "Garima Kanwar & Members"
        },
        "dataset_name": dataset["filename"],
        "generated_at": datetime.utcnow().isoformat(),
        "total_transactions_audited": dataset["row_count"],
        "anomalies_flagged": dataset["anomalies_detected"],
        "high_risk_ratio": f"{dataset['high_risk_ratio']}%",
        "detailed_flagged_transactions": txs
    }

    return JSONResponse(
        content=report,
        headers={"Content-Disposition": f"attachment; filename=BitSentinel_Audit_{dataset['filename']}.json"}
    )

@app.delete("/api/admin/datasets/{dataset_id}")
async def delete_dataset(dataset_id: int):
    conn = get_db()
    cursor = conn.cursor()
    cursor.execute("DELETE FROM dataset_transactions WHERE dataset_id = ?", (dataset_id,))
    cursor.execute("DELETE FROM datasets WHERE id = ?", (dataset_id,))
    conn.commit()
    conn.close()
    return {"status": "success", "message": f"Dataset #{dataset_id} deleted"}

@app.post("/api/admin/load-sample")
async def load_sample_dataset(user_id: int = 1):
    """
    Convenience endpoint for Hackathon demonstration:
    Automatically loads and analyzes the pre-built enterprise sample dataset.
    """
    sample_path = os.path.join(STATIC_DIR, "samples", "sample_enterprise_btc_transfers.csv")
    if not os.path.exists(sample_path):
        raise HTTPException(status_code=404, detail="Sample dataset file not found.")

    with open(sample_path, "rb") as f:
        file_bytes = f.read()

    # Create dummy upload
    df = pd.read_csv(io.BytesIO(file_bytes))
    records = df.to_dict(orient="records")

    conn = get_db()
    cursor = conn.cursor()
    now_iso = datetime.utcnow().isoformat()
    filename = "enterprise_bitcoin_transfers.csv"

    cursor.execute("""
    INSERT INTO datasets (user_id, filename, file_type, row_count, anomalies_detected, high_risk_ratio, status, uploaded_at, analysis_summary)
    VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)
    """, (user_id, filename, "CSV", len(records), 0, 0.0, "Completed", now_iso, "{}"))
    dataset_id = cursor.lastrowid

    anomalies_detected = 0
    total_risk = 0.0
    high_risk_count = 0

    for idx, row in enumerate(records):
        tx_hash = str(row.get("tx_hash"))
        source = str(row.get("source_address"))
        dest = str(row.get("dest_address"))
        amt_btc = float(row.get("amount_btc", 0.0))
        fee_sat = float(row.get("fee_sat_vb", 25.0))
        in_cnt = int(row.get("inputs_count", 1))
        out_cnt = int(row.get("outputs_count", 2))
        change_rat = float(row.get("change_ratio", 0.85))

        payload = {
            "tx_hash": tx_hash,
            "source_address": source,
            "dest_address": dest,
            "amount_btc": amt_btc,
            "fee_sat_vb": fee_sat,
            "inputs_count": in_cnt,
            "outputs_count": out_cnt,
            "change_ratio": change_rat
        }

        res = detector.analyze_transaction(payload)
        risk_score = res["risk_score"]
        risk_lvl = res["risk_level"]
        tags_str = ", ".join(res["anomaly_tags"])

        total_risk += risk_score
        if risk_lvl in ["HIGH", "CRITICAL"]:
            anomalies_detected += 1
            high_risk_count += 1
        elif risk_lvl == "MEDIUM":
            anomalies_detected += 1

        cursor.execute("""
        INSERT INTO dataset_transactions (
            dataset_id, tx_hash, source_address, dest_address, amount_btc, 
            amount_usd, fee_sat_vb, timestamp, risk_score, risk_level, 
            anomaly_tags, explanation
        ) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)
        """, (
            dataset_id, tx_hash, source, dest, amt_btc, 
            res["amount_usd"], fee_sat, datetime.utcnow().strftime("%Y-%m-%d %H:%M:%S"),
            risk_score, risk_lvl, tags_str, res["explanation"]
        ))

    summary_data = {
        "total_records": len(records),
        "anomalies_count": anomalies_detected,
        "high_risk_count": high_risk_count,
        "average_risk_score": round(total_risk / len(records), 1),
        "high_risk_ratio_pct": round((high_risk_count / len(records)) * 100, 1),
        "scan_engine": "BitSentinel AI Ensemble v3.4",
        "recommended_action": "High-risk flows identified: Conti ransomware peel hop & Lazarus mixer traffic detected."
    }

    cursor.execute("""
    UPDATE datasets 
    SET anomalies_detected = ?, high_risk_ratio = ?, analysis_summary = ?
    WHERE id = ?
    """, (anomalies_detected, summary_data["high_risk_ratio_pct"], json.dumps(summary_data), dataset_id))

    conn.commit()
    conn.close()

    return {
        "status": "success",
        "message": "Sample dataset analyzed and loaded!",
        "dataset_id": dataset_id,
        "summary": summary_data
    }

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)
