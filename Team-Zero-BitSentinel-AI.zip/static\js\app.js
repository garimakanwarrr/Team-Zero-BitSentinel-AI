/**
 * BitSentinel AI - Main Frontend Orchestration
 * Coordinates background canvas animation, telemetry polling, tab routing,
 * and AI forensic diagnostics sandbox.
 */

document.addEventListener('DOMContentLoaded', () => {
  // 1. Initialize Background Cyber Canvas
  initBackgroundCanvas();

  // 2. Tab Navigation
  initTabs();

  // 3. Telemetry KPI Poller
  initKpiPoller();

  // 4. Instantiate Core Subsystems
  window.chartsManager = new window.SentinelChartsManager();
  window.chartsManager.initCharts();

  window.streamManager = new window.TransactionStreamManager();
  window.networkVisualizer = new window.BitcoinNetworkVisualizer('graphCanvas');
  window.adminManager = new window.AdminPortalManager();

  // 5. Initialize AI Anomaly Sandbox (Tab 2)
  initAiAnomalySandbox();

  // 6. Modal Controls
  initModals();
});

// BACKGROUND CANVAS WITH CYBERNETIC PARTICLES
function initBackgroundCanvas() {
  const canvas = document.getElementById('bgCanvas');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');

  let width = (canvas.width = window.innerWidth);
  let height = (canvas.height = window.innerHeight);

  window.addEventListener('resize', () => {
    width = canvas.width = window.innerWidth;
    height = canvas.height = window.innerHeight;
  });

  const particles = [];
  const pCount = Math.min(65, Math.floor(width / 22));

  for (let i = 0; i < pCount; i++) {
    particles.push({
      x: Math.random() * width,
      y: Math.random() * height,
      vx: (Math.random() - 0.5) * 0.45,
      vy: (Math.random() - 0.5) * 0.45,
      radius: Math.random() * 2 + 1,
      color: Math.random() > 0.8 ? '#f7931a' : '#00f0ff'
    });
  }

  function render() {
    ctx.clearRect(0, 0, width, height);

    // Draw connecting lines
    for (let i = 0; i < particles.length; i++) {
      for (let j = i + 1; j < particles.length; j++) {
        const dx = particles[j].x - particles[i].x;
        const dy = particles[j].y - particles[i].y;
        const dist = Math.sqrt(dx * dx + dy * dy);
        if (dist < 120) {
          ctx.strokeStyle = `rgba(0, 240, 255, ${0.15 * (1 - dist / 120)})`;
          ctx.lineWidth = 0.8;
          ctx.beginPath();
          ctx.moveTo(particles[i].x, particles[i].y);
          ctx.lineTo(particles[j].x, particles[j].y);
          ctx.stroke();
        }
      }
    }

    // Draw particles
    particles.forEach(p => {
      p.x += p.vx;
      p.y += p.vy;
      if (p.x < 0 || p.x > width) p.vx *= -1;
      if (p.y < 0 || p.y > height) p.vy *= -1;

      ctx.beginPath();
      ctx.arc(p.x, p.y, p.radius, 0, Math.PI * 2);
      ctx.fillStyle = p.color;
      ctx.fill();
    });

    requestAnimationFrame(render);
  }

  render();
}

// TAB NAVIGATION
function initTabs() {
  const tabBtns = document.querySelectorAll('.tab-btn');
  const tabPanes = document.querySelectorAll('.tab-pane');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const targetId = btn.getAttribute('data-tab');

      tabBtns.forEach(b => b.classList.remove('active'));
      tabPanes.forEach(p => p.classList.remove('active'));

      btn.classList.add('active');
      const targetPane = document.getElementById(targetId);
      if (targetPane) targetPane.classList.add('active');

      // Refresh graph size if switching to graph tab
      if (targetId === 'tabGraph' && window.networkVisualizer) {
        window.networkVisualizer.initCanvasSize();
      }
    });
  });
}

// TELEMETRY KPI POLLER
function initKpiPoller() {
  async function pollStats() {
    try {
      const res = await fetch('/api/telemetry/stats');
      const data = await res.json();

      document.getElementById('kpiBtcPrice').textContent = `$${data.btc_price_usd.toLocaleString()}`;
      document.getElementById('kpiTps').textContent = `${data.tps} TPS`;
      document.getElementById('kpiMempool').textContent = `${data.mempool_tx_count.toLocaleString()} TXs`;
      document.getElementById('kpiGasPriority').textContent = `${data.fastest_fee_sat_vb} sat/vB`;
      document.getElementById('kpiThreatStatus').textContent = data.threat_status;
      document.getElementById('kpiBlockHeight').textContent = `#${data.block_height}`;
    } catch (err) {
      console.warn('KPI poll error', err);
    }
  }

  pollStats();
  setInterval(pollStats, 4000);
}

// AI ANOMALY DETECTION SANDBOX
function initAiAnomalySandbox() {
  // Load Presets
  fetch('/api/ai/preset-scenarios')
    .then(res => res.json())
    .then(data => {
      const container = document.getElementById('aiPresetsList');
      if (!container) return;

      container.innerHTML = data.scenarios.map(sc => `
        <div class="preset-card" onclick="window.loadAiScenario('${sc.id}')">
          <div class="preset-header">
            <span class="preset-title">${sc.title}</span>
            <span class="panel-title-badge">${sc.payload.forced_anomaly || 'BENIGN'}</span>
          </div>
          <p class="preset-desc">${sc.description}</p>
        </div>
      `).join('');

      window.scenariosData = data.scenarios;
    });

  window.loadAiScenario = function(scenarioId) {
    if (!window.scenariosData) return;
    const sc = window.scenariosData.find(s => s.id === scenarioId);
    if (!sc) return;

    document.getElementById('inputAiSource').value = sc.payload.source_address;
    document.getElementById('inputAiDest').value = sc.payload.dest_address;
    document.getElementById('inputAiAmount').value = sc.payload.amount_btc;
    document.getElementById('inputAiFee').value = sc.payload.fee_sat_vb;
    document.getElementById('inputAiInputs').value = sc.payload.inputs_count;
    document.getElementById('inputAiOutputs').value = sc.payload.outputs_count;
    document.getElementById('inputAiChangeRatio').value = sc.payload.change_ratio;
    document.getElementById('inputAiEqualOutputs').checked = !!sc.payload.equal_outputs;
    document.getElementById('selectAiForcedAnomaly').value = sc.payload.forced_anomaly || '';

    runAiDiagnostic();
  };

  const form = document.getElementById('formAiDiagnostic');
  if (form) {
    form.addEventListener('submit', (e) => {
      e.preventDefault();
      runAiDiagnostic();
    });
  }
}

async function runAiDiagnostic() {
  const source = document.getElementById('inputAiSource').value;
  const dest = document.getElementById('inputAiDest').value;
  const amount = parseFloat(document.getElementById('inputAiAmount').value) || 0.1;
  const fee = parseFloat(document.getElementById('inputAiFee').value) || 25;
  const inCount = parseInt(document.getElementById('inputAiInputs').value) || 1;
  const outCount = parseInt(document.getElementById('inputAiOutputs').value) || 2;
  const changeRatio = parseFloat(document.getElementById('inputAiChangeRatio').value) || 0.85;
  const equalOutputs = document.getElementById('inputAiEqualOutputs').checked;
  const forcedAnomaly = document.getElementById('selectAiForcedAnomaly').value || null;

  const payload = {
    source_address: source,
    dest_address: dest,
    amount_btc: amount,
    fee_sat_vb: fee,
    inputs_count: inCount,
    outputs_count: outCount,
    change_ratio: changeRatio,
    equal_outputs: equalOutputs,
    forced_anomaly: forcedAnomaly
  };

  try {
    const res = await fetch('/api/ai/analyze-transaction', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(payload)
    });
    const data = await res.json();
    renderAiDiagnosticResult(data.analysis);
  } catch (err) {
    console.error('Error running AI analysis', err);
  }
}

function renderAiDiagnosticResult(analysis) {
  // Update Gauge Score
  const score = analysis.risk_score;
  const scoreEl = document.getElementById('gaugeScoreVal');
  const levelEl = document.getElementById('gaugeRiskLevel');
  const circleEl = document.getElementById('gaugeSvgCircle');

  if (scoreEl) scoreEl.textContent = score;
  if (levelEl) {
    levelEl.textContent = analysis.risk_level;
    levelEl.className = `risk-badge ${analysis.risk_level.toLowerCase()}`;
  }

  if (circleEl) {
    // 440 circumference
    const offset = 440 - (440 * (score / 100));
    circleEl.style.strokeDashoffset = offset;
    circleEl.style.stroke = analysis.risk_color;
  }

  // Model Confidence
  const confEl = document.getElementById('aiModelConfidence');
  if (confEl) confEl.textContent = `${analysis.model_confidence}%`;

  // SHAP Feature Bars
  const featContainer = document.getElementById('aiFeatureBarsList');
  if (featContainer && analysis.feature_attributions) {
    featContainer.innerHTML = Object.entries(analysis.feature_attributions).map(([k, v]) => `
      <div class="feature-bar-item">
        <div class="feature-bar-label">
          <span>${k}</span>
          <span style="color: var(--neon-cyan);">${v.toFixed(1)} pts</span>
        </div>
        <div class="feature-progress-track">
          <div class="feature-progress-fill" style="width: ${Math.min(100, v * 2)}%;"></div>
        </div>
      </div>
    `).join('');
  }

  // Statements
  document.getElementById('aiForensicStatement').textContent = analysis.explanation;
  document.getElementById('aiMitigationStatement').textContent = analysis.mitigation_action;
}

// MODALS
function initModals() {
  // Team ZERO Showcase Modal
  const modalTeam = document.getElementById('modalTeamZero');
  const btnOpenTeam = document.getElementById('btnOpenTeamModal');
  const btnCloseTeam = document.getElementById('btnCloseTeamModal');

  if (btnOpenTeam && modalTeam) {
    btnOpenTeam.addEventListener('click', () => modalTeam.classList.add('active'));
  }
  if (btnCloseTeam && modalTeam) {
    btnCloseTeam.addEventListener('click', () => modalTeam.classList.remove('active'));
  }

  // Tx Detail Modal Close
  const modalTx = document.getElementById('txDetailModal');
  const btnCloseTx = document.getElementById('btnCloseTxModal');
  if (btnCloseTx && modalTx) {
    btnCloseTx.addEventListener('click', () => modalTx.classList.remove('active'));
  }

  // Close modals on outside click
  window.addEventListener('click', (e) => {
    if (e.target === modalTeam) modalTeam.classList.remove('active');
    if (e.target === modalTx) modalTx.classList.remove('active');
  });
}
