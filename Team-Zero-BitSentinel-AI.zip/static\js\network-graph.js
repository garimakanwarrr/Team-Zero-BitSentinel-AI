/**
 * BitSentinel AI - Network Graph Visualization Engine
 * Interactive Force-Directed Canvas Network with Physics and Flow Particle Simulation.
 */

class BitcoinNetworkVisualizer {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    if (!this.canvas) return;
    this.ctx = this.canvas.getContext('2d');
    
    this.nodes = [];
    this.links = [];
    this.particles = [];
    
    this.selectedNode = null;
    this.hoveredNode = null;
    this.draggedNode = null;
    
    this.zoom = 1.0;
    this.panX = 0;
    this.panY = 0;
    this.isPanning = false;
    this.startPanX = 0;
    this.startPanY = 0;
    
    this.filterType = 'ALL';
    this.searchQuery = '';
    
    this.initCanvasSize();
    this.bindEvents();
    this.loadData();
    this.startAnimationLoop();
  }

  initCanvasSize() {
    const rect = this.canvas.parentElement.getBoundingClientRect();
    this.canvas.width = rect.width || 900;
    this.canvas.height = rect.height || 600;
    this.panX = this.canvas.width / 2;
    this.panY = this.canvas.height / 2;
  }

  async loadData() {
    try {
      const res = await fetch('/api/network/graph-data');
      const data = await res.json();
      
      // Initialize node physics coordinates in a radial distribution
      const count = data.nodes.length;
      this.nodes = data.nodes.map((node, i) => {
        const angle = (i / count) * Math.PI * 2;
        const radius = 160 + (i % 3) * 60;
        return {
          ...node,
          x: Math.cos(angle) * radius,
          y: Math.sin(angle) * radius,
          vx: 0,
          vy: 0,
          radius: node.type === 'WHALE' || node.type === 'EXCHANGE' ? 24 : 18
        };
      });

      this.links = data.links;
      this.initParticles();
    } catch (err) {
      console.error('Failed to load graph data', err);
    }
  }

  initParticles() {
    this.particles = [];
    // Spawn flow particles along links
    this.links.forEach((link, idx) => {
      const count = Math.min(4, Math.max(1, Math.floor(link.amount / 5)));
      for (let i = 0; i < count; i++) {
        this.particles.push({
          linkIdx: idx,
          progress: Math.random(),
          speed: 0.004 + Math.random() * 0.006,
          size: 2.5 + Math.min(2.5, link.amount / 15),
          color: link.risk === 'CRITICAL' ? '#ef4444' : link.risk === 'HIGH' ? '#f59e0b' : '#00f0ff'
        });
      }
    });
  }

  getNodeColor(type, risk) {
    if (risk === 'CRITICAL') return '#ef4444';
    if (type === 'MIXER') return '#a855f7';
    if (type === 'PEELING_HOP') return '#f59e0b';
    if (type === 'EXCHANGE') return '#00f0ff';
    if (type === 'WHALE') return '#f7931a';
    return '#10b981';
  }

  bindEvents() {
    window.addEventListener('resize', () => this.initCanvasSize());

    this.canvas.addEventListener('mousedown', (e) => {
      const pos = this.getCanvasCoords(e);
      const clicked = this.findNodeAt(pos.x, pos.y);
      if (clicked) {
        this.draggedNode = clicked;
        this.selectNode(clicked);
      } else {
        this.isPanning = true;
        this.startPanX = e.clientX - this.panX;
        this.startPanY = e.clientY - this.panY;
      }
    });

    window.addEventListener('mousemove', (e) => {
      if (this.draggedNode) {
        const pos = this.getCanvasCoords(e);
        this.draggedNode.x = pos.x;
        this.draggedNode.y = pos.y;
      } else if (this.isPanning) {
        this.panX = e.clientX - this.startPanX;
        this.panY = e.clientY - this.startPanY;
      } else {
        const pos = this.getCanvasCoords(e);
        this.hoveredNode = this.findNodeAt(pos.x, pos.y);
        this.canvas.style.cursor = this.hoveredNode ? 'pointer' : 'default';
      }
    });

    window.addEventListener('mouseup', () => {
      this.draggedNode = null;
      this.isPanning = false;
    });

    this.canvas.addEventListener('wheel', (e) => {
      e.preventDefault();
      const zoomFactor = e.deltaY < 0 ? 1.1 : 0.9;
      this.zoom = Math.min(2.5, Math.max(0.4, this.zoom * zoomFactor));
    });
  }

  getCanvasCoords(e) {
    const rect = this.canvas.getBoundingClientRect();
    const mouseX = e.clientX - rect.left;
    const mouseY = e.clientY - rect.top;
    return {
      x: (mouseX - this.panX) / this.zoom,
      y: (mouseY - this.panY) / this.zoom
    };
  }

  findNodeAt(x, y) {
    return this.nodes.find(n => {
      const dx = n.x - x;
      const dy = n.y - y;
      return Math.sqrt(dx * dx + dy * dy) <= n.radius + 6;
    });
  }

  selectNode(node) {
    this.selectedNode = node;
    const inspector = document.getElementById('graphInspector');
    if (inspector) {
      inspector.style.display = 'block';
      document.getElementById('inspectNodeLabel').textContent = node.label;
      document.getElementById('inspectNodeAddress').textContent = node.address;
      document.getElementById('inspectNodeType').textContent = node.type;
      document.getElementById('inspectNodeRisk').textContent = node.risk;
      document.getElementById('inspectNodeRisk').className = `risk-badge ${node.risk.toLowerCase()}`;
      document.getElementById('inspectNodeBalance').textContent = `${node.balance.toFixed(4)} BTC ($${(node.balance * 68450).toLocaleString()})`;
      document.getElementById('inspectNodeTxCount').textContent = node.tx_count;
    }
  }

  updatePhysics() {
    // Spring physics simulation
    const repulsion = 3200;
    const springLength = 140;
    const springK = 0.02;
    const damping = 0.88;

    // Repulsion between nodes
    for (let i = 0; i < this.nodes.length; i++) {
      for (let j = i + 1; j < this.nodes.length; j++) {
        const n1 = this.nodes[i];
        const n2 = this.nodes[j];
        const dx = n2.x - n1.x;
        const dy = n2.y - n1.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        if (dist < 350) {
          const force = repulsion / (dist * dist);
          const fx = (dx / dist) * force;
          const fy = (dy / dist) * force;
          if (n1 !== this.draggedNode) { n1.vx -= fx; n1.vy -= fy; }
          if (n2 !== this.draggedNode) { n2.vx += fx; n2.vy += fy; }
        }
      }
    }

    // Link attraction
    this.links.forEach(link => {
      const sNode = this.nodes.find(n => n.id === link.source);
      const tNode = this.nodes.find(n => n.id === link.target);
      if (sNode && tNode) {
        const dx = tNode.x - sNode.x;
        const dy = tNode.y - sNode.y;
        const dist = Math.sqrt(dx * dx + dy * dy) || 1;
        const displacement = dist - springLength;
        const force = displacement * springK;
        const fx = (dx / dist) * force;
        const fy = (dy / dist) * force;
        if (sNode !== this.draggedNode) { sNode.vx += fx; sNode.vy += fy; }
        if (tNode !== this.draggedNode) { tNode.vx -= fx; tNode.vy -= fy; }
      }
    });

    // Center gravity & velocity dampening
    this.nodes.forEach(n => {
      if (n !== this.draggedNode) {
        n.vx -= n.x * 0.002;
        n.vy -= n.y * 0.002;
        n.vx *= damping;
        n.vy *= damping;
        n.x += n.vx;
        n.y += n.vy;
      }
    });

    // Update satoshi flow particles
    this.particles.forEach(p => {
      p.progress += p.speed;
      if (p.progress >= 1.0) p.progress = 0;
    });
  }

  draw() {
    this.ctx.clearRect(0, 0, this.canvas.width, this.canvas.height);

    this.ctx.save();
    this.ctx.translate(this.panX, this.panY);
    this.ctx.scale(this.zoom, this.zoom);

    // Draw grid background lines
    this.ctx.strokeStyle = 'rgba(255, 255, 255, 0.03)';
    this.ctx.lineWidth = 1;
    const gridStep = 80;
    const ext = 800;
    for (let x = -ext; x <= ext; x += gridStep) {
      this.ctx.beginPath();
      this.ctx.moveTo(x, -ext);
      this.ctx.lineTo(x, ext);
      this.ctx.stroke();
    }
    for (let y = -ext; y <= ext; y += gridStep) {
      this.ctx.beginPath();
      this.ctx.moveTo(-ext, y);
      this.ctx.lineTo(ext, y);
      this.ctx.stroke();
    }

    // Draw Links
    this.links.forEach(link => {
      const s = this.nodes.find(n => n.id === link.source);
      const t = this.nodes.find(n => n.id === link.target);
      if (!s || !t) return;

      const isCritical = link.risk === 'CRITICAL';
      const isSelected = this.selectedNode && (this.selectedNode.id === s.id || this.selectedNode.id === t.id);

      this.ctx.beginPath();
      this.ctx.moveTo(s.x, s.y);
      this.ctx.lineTo(t.x, t.y);
      this.ctx.strokeStyle = isSelected 
        ? '#00f0ff' 
        : isCritical ? 'rgba(239, 68, 68, 0.45)' : 'rgba(255, 255, 255, 0.12)';
      this.ctx.lineWidth = isSelected ? 2.5 : isCritical ? 2.0 : 1.2;
      this.ctx.stroke();

      // Draw arrow head
      const angle = Math.atan2(t.y - s.y, t.x - s.x);
      const targetEdgeX = t.x - Math.cos(angle) * (t.radius + 6);
      const targetEdgeY = t.y - Math.sin(angle) * (t.radius + 6);
      
      this.ctx.beginPath();
      this.ctx.moveTo(targetEdgeX, targetEdgeY);
      this.ctx.lineTo(targetEdgeX - 8 * Math.cos(angle - Math.PI / 7), targetEdgeY - 8 * Math.sin(angle - Math.PI / 7));
      this.ctx.lineTo(targetEdgeX - 8 * Math.cos(angle + Math.PI / 7), targetEdgeY - 8 * Math.sin(angle + Math.PI / 7));
      this.ctx.closePath();
      this.ctx.fillStyle = isCritical ? '#ef4444' : 'rgba(255, 255, 255, 0.35)';
      this.ctx.fill();
    });

    // Draw Sat Flow Particles
    this.particles.forEach(p => {
      const link = this.links[p.linkIdx];
      if (!link) return;
      const s = this.nodes.find(n => n.id === link.source);
      const t = this.nodes.find(n => n.id === link.target);
      if (!s || !t) return;

      const px = s.x + (t.x - s.x) * p.progress;
      const py = s.y + (t.y - s.y) * p.progress;

      this.ctx.beginPath();
      this.ctx.arc(px, py, p.size, 0, Math.PI * 2);
      this.ctx.fillStyle = p.color;
      this.ctx.shadowColor = p.color;
      this.ctx.shadowBlur = 10;
      this.ctx.fill();
      this.ctx.shadowBlur = 0;
    });

    // Draw Nodes
    this.nodes.forEach(node => {
      const color = this.getNodeColor(node.type, node.risk);
      const isSelected = this.selectedNode && this.selectedNode.id === node.id;
      const isHovered = this.hoveredNode && this.hoveredNode.id === node.id;

      // Outer glow ring
      this.ctx.beginPath();
      this.ctx.arc(node.x, node.y, node.radius + (isSelected ? 8 : 4), 0, Math.PI * 2);
      this.ctx.strokeStyle = color;
      this.ctx.lineWidth = isSelected ? 3 : 1.5;
      this.ctx.shadowColor = color;
      this.ctx.shadowBlur = isSelected ? 18 : 8;
      this.ctx.stroke();
      this.ctx.shadowBlur = 0;

      // Inner body
      this.ctx.beginPath();
      this.ctx.arc(node.x, node.y, node.radius, 0, Math.PI * 2);
      this.ctx.fillStyle = '#0a101a';
      this.ctx.fill();

      // Node core icon/dot
      this.ctx.beginPath();
      this.ctx.arc(node.x, node.y, 6, 0, Math.PI * 2);
      this.ctx.fillStyle = color;
      this.ctx.fill();

      // Node Label
      this.ctx.font = '10px "JetBrains Mono", monospace';
      this.ctx.fillStyle = isSelected ? '#ffffff' : '#cbd5e1';
      this.ctx.textAlign = 'center';
      this.ctx.fillText(node.label, node.x, node.y + node.radius + 14);
    });

    this.ctx.restore();
  }

  startAnimationLoop() {
    const loop = () => {
      this.updatePhysics();
      this.draw();
      requestAnimationFrame(loop);
    };
    requestAnimationFrame(loop);
  }

  resetView() {
    this.zoom = 1.0;
    this.panX = this.canvas.width / 2;
    this.panY = this.canvas.height / 2;
  }

  filterByType(type) {
    this.filterType = type;
    // Highlight or filter nodes
  }
}

// Global instance
window.BitcoinNetworkVisualizer = BitcoinNetworkVisualizer;
