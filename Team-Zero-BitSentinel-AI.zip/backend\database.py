"""
BitSentinel AI - Database Layer
Supports SQLite storage for Users, Organizations, Uploaded Datasets, and Analyzed Transactions.
"""

import sqlite3
import hashlib
import os
import json
from datetime import datetime

DB_PATH = os.path.join(os.path.dirname(__file__), "..", "sentinel.db")

def get_db():
    conn = sqlite3.connect(DB_PATH)
    conn.row_factory = sqlite3.Row
    return conn

def hash_password(password: str) -> str:
    salt = "bitsentinel_zero_salt_2026"
    return hashlib.sha256((password + salt).encode('utf-8')).hexdigest()

def init_db():
    conn = get_db()
    cursor = conn.cursor()

    # 1. Users Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        username TEXT UNIQUE NOT NULL,
        email TEXT UNIQUE NOT NULL,
        password_hash TEXT NOT NULL,
        organization TEXT NOT NULL,
        role TEXT DEFAULT 'Security Analyst',
        created_at TEXT NOT NULL
    )
    """)

    # 2. Uploaded Datasets Table
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS datasets (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        user_id INTEGER,
        filename TEXT NOT NULL,
        file_type TEXT NOT NULL,
        row_count INTEGER DEFAULT 0,
        anomalies_detected INTEGER DEFAULT 0,
        high_risk_ratio REAL DEFAULT 0.0,
        status TEXT DEFAULT 'Completed',
        uploaded_at TEXT NOT NULL,
        analysis_summary TEXT,
        FOREIGN KEY (user_id) REFERENCES users (id)
    )
    """)

    # 3. Analyzed Transactions Table (from uploads)
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS dataset_transactions (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        dataset_id INTEGER NOT NULL,
        tx_hash TEXT NOT NULL,
        source_address TEXT NOT NULL,
        dest_address TEXT NOT NULL,
        amount_btc REAL NOT NULL,
        amount_usd REAL NOT NULL,
        fee_sat_vb REAL NOT NULL,
        timestamp TEXT NOT NULL,
        risk_score REAL NOT NULL,
        risk_level TEXT NOT NULL,
        anomaly_tags TEXT NOT NULL,
        explanation TEXT NOT NULL,
        FOREIGN KEY (dataset_id) REFERENCES datasets (id)
    )
    """)

    conn.commit()

    # Seed default admin user for quick Hackathon demo
    cursor.execute("SELECT id FROM users WHERE username = 'admin'")
    if not cursor.fetchone():
        admin_pass = hash_password("admin123")
        now = datetime.utcnow().isoformat()
        cursor.execute("""
        INSERT INTO users (username, email, password_hash, organization, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """, ("admin", "admin@bitsentinel.ai", admin_pass, "BitSentinel Core Defense", "Lead Investigator", now))

        # Seed standard Team ZERO analyst user
        team_pass = hash_password("zero2026")
        cursor.execute("""
        INSERT INTO users (username, email, password_hash, organization, role, created_at)
        VALUES (?, ?, ?, ?, ?, ?)
        """, ("garima.zero", "garima@teamzero.tech", team_pass, "Team ZERO Blockchain Labs", "Team Leader / Security Architect", now))
        conn.commit()

    conn.close()

if __name__ == "__main__":
    init_db()
    print("Database initialized successfully!")
