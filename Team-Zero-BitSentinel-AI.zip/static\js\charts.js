/**
 * BitSentinel AI - Charts & Telemetry Visualizations
 * Powered by Chart.js with Cyber-Themed Gradients and Neon Glows.
 */

class SentinelChartsManager {
  constructor() {
    this.velocityChart = null;
    this.riskChart = null;
    this.typesChart = null;
  }

  async initCharts() {
    try {
      const res = await fetch('/api/telemetry/charts');
      const data = await res.json();
      this.renderVelocityChart(data.labels, data.volume_series, data.anomaly_series);
      this.renderRiskChart(data.risk_distribution);
      this.renderTypesChart(data.anomaly_types);
    } catch (err) {
      console.error('Error fetching chart data', err);
    }
  }

  renderVelocityChart(labels, volume, anomalies) {
    const ctx = document.getElementById('chartVolumeVelocity');
    if (!ctx) return;

    if (this.velocityChart) this.velocityChart.destroy();

    const chartCtx = ctx.getContext('2d');
    const gradCyan = chartCtx.createLinearGradient(0, 0, 0, 240);
    gradCyan.addColorStop(0, 'rgba(0, 240, 255, 0.35)');
    gradCyan.addColorStop(1, 'rgba(0, 240, 255, 0.0)');

    const gradRed = chartCtx.createLinearGradient(0, 0, 0, 240);
    gradRed.addColorStop(0, 'rgba(239, 68, 68, 0.4)');
    gradRed.addColorStop(1, 'rgba(239, 68, 68, 0.0)');

    this.velocityChart = new Chart(chartCtx, {
      type: 'line',
      data: {
        labels: labels,
        datasets: [
          {
            label: 'Volume Flow (BTC)',
            data: volume,
            borderColor: '#00f0ff',
            backgroundColor: gradCyan,
            fill: true,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: '#00f0ff',
            yAxisID: 'y'
          },
          {
            label: 'Flagged Anomalies',
            data: anomalies,
            borderColor: '#ef4444',
            backgroundColor: gradRed,
            fill: true,
            tension: 0.4,
            borderWidth: 2,
            pointRadius: 3,
            pointBackgroundColor: '#ef4444',
            yAxisID: 'y1'
          }
        ]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        interaction: { mode: 'index', intersect: false },
        plugins: {
          legend: {
            labels: { color: '#94a3b8', font: { family: 'JetBrains Mono', size: 10 } }
          }
        },
        scales: {
          x: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#64748b', font: { family: 'JetBrains Mono', size: 9 } }
          },
          y: {
            type: 'linear',
            display: true,
            position: 'left',
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#00f0ff', font: { family: 'JetBrains Mono', size: 9 } }
          },
          y1: {
            type: 'linear',
            display: true,
            position: 'right',
            grid: { drawOnChartArea: false },
            ticks: { color: '#ef4444', font: { family: 'JetBrains Mono', size: 9 } }
          }
        }
      }
    });
  }

  renderRiskChart(distribution) {
    const ctx = document.getElementById('chartRiskDistribution');
    if (!ctx) return;

    if (this.riskChart) this.riskChart.destroy();

    this.riskChart = new Chart(ctx.getContext('2d'), {
      type: 'doughnut',
      data: {
        labels: Object.keys(distribution),
        datasets: [{
          data: Object.values(distribution),
          backgroundColor: ['#10b981', '#eab308', '#f97316', '#ef4444'],
          borderColor: '#06090e',
          borderWidth: 3
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        cutout: '72%',
        plugins: {
          legend: {
            position: 'bottom',
            labels: { color: '#94a3b8', font: { family: 'JetBrains Mono', size: 9 }, padding: 8 }
          }
        }
      }
    });
  }

  renderTypesChart(anomalyTypes) {
    const ctx = document.getElementById('chartAnomalyTypes');
    if (!ctx) return;

    if (this.typesChart) this.typesChart.destroy();

    this.typesChart = new Chart(ctx.getContext('2d'), {
      type: 'bar',
      data: {
        labels: Object.keys(anomalyTypes),
        datasets: [{
          label: 'Detections (24h)',
          data: Object.values(anomalyTypes),
          backgroundColor: ['#f59e0b', '#a855f7', '#00f0ff', '#ef4444', '#38bdf8'],
          borderRadius: 4
        }]
      },
      options: {
        responsive: true,
        maintainAspectRatio: false,
        plugins: {
          legend: { display: false }
        },
        scales: {
          x: {
            grid: { display: false },
            ticks: { color: '#94a3b8', font: { family: 'JetBrains Mono', size: 9 } }
          },
          y: {
            grid: { color: 'rgba(255,255,255,0.05)' },
            ticks: { color: '#64748b', font: { family: 'JetBrains Mono', size: 9 } }
          }
        }
      }
    });
  }
}

window.SentinelChartsManager = SentinelChartsManager;
