@echo off
title BitSentinel AI - Team ZERO
echo ===================================================================
echo BitSentinel AI: Guarding Every Bitcoin Transaction
echo Hackathon: AI Powered Monitoring ^& Analysis of Bitcoin Transaction Traffic
echo Team ZERO ^| Team Leader: Garima Kanwar ^& Members
echo ===================================================================
echo.
echo Starting BitSentinel AI FastAPI Web Server...
start "" "http://127.0.0.1:8000"
python -m uvicorn main:app --host 127.0.0.1 --port 8000 --reload
pause
