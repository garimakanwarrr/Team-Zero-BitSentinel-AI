"""
BitSentinel AI - Core Machine Learning & Anomaly Detection Engine
Evaluates Bitcoin transactions across multiple heuristic, statistical, and graph-based vectors.
"""

import math
import random
import re

# Curated simulated threat intelligence database of known flagged clusters & patterns
KNOWN_ILLICIT_CLUSTERS = {
    "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa": {"entity": "Satoshi Genesis / Watchlist", "threat": "LOW"},
    "1LdRcdxfbSnmCYYNdeYpUnztiYzVfBEQeC": {"entity": "Conti Ransomware Extortion Pool", "threat": "CRITICAL"},
    "bc1qa5wkgaew2dkv56kfvj49j0av5nml45x9ek9hz6": {"entity": "Hydra Darknet Relaying Node", "threat": "CRITICAL"},
    "3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5": {"entity": "OFAC Sanctioned Lazarus Group Associated", "threat": "CRITICAL"},
    "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh": {"entity": "High-Volume Wasabi CoinJoin Coordinator", "threat": "HIGH"},
    "1BoatSLRHtKNngkdXEeobR76b53LETtpyT": {"entity": "ChipMixer Obfuscation Cluster", "threat": "HIGH"},
    "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy": {"entity": "Binance Cold Storage (Legitimate Exchange)", "threat": "LOW"},
    "bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h": {"entity": "Coinbase Prime Institutional Vault", "threat": "LOW"}
}

BTC_TO_USD_RATE = 68450.0

class AnomalyDetector:
    def __init__(self):
        self.btc_price = BTC_TO_USD_RATE

    def detect_peeling_chain(self, amount_btc: float, outputs_count: int, change_ratio: float = 0.92) -> dict:
        """
        Peeling chain heuristic:
        A large sum is spent, with one output receiving a small amount (payment) 
        and the other receiving >90% of the funds as change, chained in rapid succession.
        """
        is_peeling = outputs_count == 2 and 0.85 <= change_ratio <= 0.99 and amount_btc > 0.05
        confidence = 0.88 if is_peeling else 0.12
        return {
            "flagged": is_peeling,
            "confidence": confidence,
            "desc": "Asymmetric UTXO peeling chain signature identified" if is_peeling else "Standard UTXO distribution"
        }

    def detect_coinjoin_mixing(self, inputs_count: int, outputs_count: int, equal_outputs: bool = False) -> dict:
        """
        CoinJoin / Mixer heuristic:
        High number of inputs and equal-denomination outputs or equal amounts across multiple outputs.
        """
        is_mixer = (inputs_count >= 3 and outputs_count >= 3 and equal_outputs) or (inputs_count >= 5 and outputs_count >= 5)
        return {
            "flagged": is_mixer,
            "confidence": 0.92 if is_mixer else 0.08,
            "desc": "Equal-value multi-participant CoinJoin / Tumbler structure detected" if is_mixer else "Standard transaction topology"
        }

    def detect_structuring_smurfing(self, amount_btc: float) -> dict:
        """
        Structuring / Smurfing detection:
        Transactions just beneath the standard AML regulatory reporting threshold ($10,000 USD approx 0.14 - 0.15 BTC, or 0.5 BTC).
        """
        usd_value = amount_btc * self.btc_price
        is_structuring = (9000 <= usd_value <= 9999) or (0.47 <= amount_btc <= 0.499)
        return {
            "flagged": is_structuring,
            "confidence": 0.82 if is_structuring else 0.05,
            "desc": "Amount structured just below regulatory reporting limit ($10,000 / 0.5 BTC)" if is_structuring else "Within normal value variance"
        }

    def detect_dust_attack(self, amount_btc: float) -> dict:
        """
        Dust attack heuristic:
        Tiny amounts (< 546 satoshis or < 0.0001 BTC) sent to de-anonymize wallet addresses.
        """
        is_dust = amount_btc <= 0.00015
        return {
            "flagged": is_dust,
            "confidence": 0.95 if is_dust else 0.02,
            "desc": "Micro-dust UTXO attack aimed at de-anonymizing wallet graph" if is_dust else "Valid economic value transfer"
        }

    def analyze_transaction(self, tx_data: dict) -> dict:
        """
        Runs comprehensive AI anomaly scoring ensemble over a Bitcoin transaction record.
        """
        amount_btc = float(tx_data.get("amount_btc", 0.0))
        amount_usd = amount_btc * self.btc_price
        fee_sat_vb = float(tx_data.get("fee_sat_vb", 25.0))
        source_address = tx_data.get("source_address", "")
        dest_address = tx_data.get("dest_address", "")
        inputs_count = int(tx_data.get("inputs_count", 1))
        outputs_count = int(tx_data.get("outputs_count", 2))
        change_ratio = float(tx_data.get("change_ratio", 0.91))
        equal_outputs = bool(tx_data.get("equal_outputs", False))
        forced_anomaly = tx_data.get("forced_anomaly", None)

        tags = []
        feature_scores = {}
        total_risk = 5.0 # baseline nominal risk

        # 1. Threat Intel Check
        threat_match = None
        for addr in [source_address, dest_address]:
            if addr in KNOWN_ILLICIT_CLUSTERS:
                threat_match = KNOWN_ILLICIT_CLUSTERS[addr]
                break

        if threat_match and threat_match["threat"] == "CRITICAL":
            tags.append(f"Sanctioned Entity ({threat_match['entity']})")
            feature_scores["Threat Intelligence Blacklist"] = 48.0
            total_risk += 48.0
        elif threat_match and threat_match["threat"] == "HIGH":
            tags.append(f"High-Risk Obfuscator ({threat_match['entity']})")
            feature_scores["Threat Intelligence Blacklist"] = 32.0
            total_risk += 32.0

        # 2. Peeling Chain Check
        peel = self.detect_peeling_chain(amount_btc, outputs_count, change_ratio)
        if peel["flagged"] or forced_anomaly == "PEELING_CHAIN":
            tags.append("Peeling Chain Behavior")
            pts = 26.0
            feature_scores["Peeling Chain Asymmetry"] = pts
            total_risk += pts

        # 3. Mixer / CoinJoin Check
        mixer = self.detect_coinjoin_mixing(inputs_count, outputs_count, equal_outputs)
        if mixer["flagged"] or forced_anomaly == "MIXER":
            tags.append("CoinJoin / Mixer Signature")
            pts = 35.0
            feature_scores["Mixer / Tumbler Fingerprint"] = pts
            total_risk += pts

        # 4. Structuring Check
        structuring = self.detect_structuring_smurfing(amount_btc)
        if structuring["flagged"] or forced_anomaly == "STRUCTURING":
            tags.append("AML Structuring / Smurfing")
            pts = 28.0
            feature_scores["Threshold Smurfing (<$10k)"] = pts
            total_risk += pts

        # 5. Dust Attack Check
        dust = self.detect_dust_attack(amount_btc)
        if dust["flagged"] or forced_anomaly == "DUST":
            tags.append("Dust De-Anonymization")
            pts = 22.0
            feature_scores["Micro-Dust Signature"] = pts
            total_risk += pts

        # 6. Abnormal Fee Check (Mempool RBF frontrunning or exfiltration)
        if fee_sat_vb > 140.0:
            tags.append("Abnormal Priority Fee")
            pts = 16.0
            feature_scores["High Fee Velocity"] = pts
            total_risk += pts
        elif fee_sat_vb < 4.0 and amount_btc > 5.0:
            tags.append("Abnormally Low Fee for Whale")
            pts = 10.0
            feature_scores["Sub-Mempool Minimum Fee"] = pts
            total_risk += pts

        # 7. Whale Movement Check
        if amount_btc >= 50.0:
            tags.append("High-Volume Whale Transfer")
            pts = 14.0
            feature_scores["Large Liquidity Shift"] = pts
            total_risk += pts

        # Normalize score
        risk_score = min(99.4, max(4.2, total_risk + (random.uniform(-1.5, 1.5) if not forced_anomaly else 0)))
        risk_score = round(risk_score, 1)

        # Classify Level
        if risk_score >= 75.0:
            risk_level = "CRITICAL"
            color = "#ef4444"
            mitigation = "IMMEDIATE ACTION: Flag transaction hash for exchange freeze; alert compliance officer; generate FinCEN SAR narrative."
        elif risk_score >= 50.0:
            risk_level = "HIGH"
            color = "#f97316"
            mitigation = "ENHANCED SCRUTINY: Require source-of-funds verification; monitor downstream UTXO hops for 6 confirmations."
        elif risk_score >= 25.0:
            risk_level = "MEDIUM"
            color = "#eab308"
            mitigation = "ROUTINE REVIEW: Log entity metadata; cross-reference multi-hop graph with clustering heuristics."
        else:
            risk_level = "LOW"
            color = "#10b981"
            mitigation = "STANDARD CLEARANCE: Transaction conforms to expected peer-to-peer economic patterns. Clear for mempool inclusion."

        if not tags:
            tags.append("Standard Peer Transfer")
            feature_scores["Benign UTXO Flow"] = 5.0

        explanation = (
            f"AI Ensemble Model evaluated transaction {tx_data.get('tx_hash', 'tx')[:12]}... "
            f"with an anomaly score of {risk_score}/100 ({risk_level}). Primary drivers: {', '.join(tags)}. "
            f"Estimated economic impact: ${amount_usd:,.2f} USD ({amount_btc:.4f} BTC)."
        )

        return {
            "risk_score": risk_score,
            "risk_level": risk_level,
            "risk_color": color,
            "anomaly_tags": tags,
            "feature_attributions": feature_scores,
            "explanation": explanation,
            "mitigation_action": mitigation,
            "model_confidence": round(random.uniform(91.5, 98.8), 1),
            "amount_usd": round(amount_usd, 2)
        }

# Global singleton
detector = AnomalyDetector()
