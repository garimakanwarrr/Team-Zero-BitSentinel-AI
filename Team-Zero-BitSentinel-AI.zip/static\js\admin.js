/**
 * BitSentinel AI - Admin & Organization Dataset Manager
 * Handles multi-tenant user authentication, dataset upload (CSV/JSON),
 * batch AI anomaly scanning, and exportable compliance audit reports.
 */

class AdminPortalManager {
  constructor() {
    this.currentUser = JSON.parse(localStorage.getItem('sentinel_user') || 'null');
    this.datasets = [];
    this.activeDatasetId = null;

    this.bindEvents();
    this.updateUserUI();
    this.loadDatasets();
  }

  bindEvents() {
    // Auth Tabs
    const btnShowLogin = document.getElementById('btnShowLogin');
    const btnShowRegister = document.getElementById('btnShowRegister');
    const formLogin = document.getElementById('formLogin');
    const formRegister = document.getElementById('formRegister');

    if (btnShowLogin && btnShowRegister) {
      btnShowLogin.addEventListener('click', () => {
        btnShowLogin.classList.add('active');
        btnShowRegister.classList.remove('active');
        formLogin.style.display = 'block';
        formRegister.style.display = 'none';
      });

      btnShowRegister.addEventListener('click', () => {
        btnShowRegister.classList.add('active');
        btnShowLogin.classList.remove('active');
        formRegister.style.display = 'block';
        formLogin.style.display = 'none';
      });
    }

    // Login Form Submit
    if (formLogin) {
      formLogin.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('loginUsername').value;
        const password = document.getElementById('loginPassword').value;
        await this.handleLogin(username, password);
      });
    }

    // Register Form Submit
    if (formRegister) {
      formRegister.addEventListener('submit', async (e) => {
        e.preventDefault();
        const username = document.getElementById('regUsername').value;
        const email = document.getElementById('regEmail').value;
        const password = document.getElementById('regPassword').value;
        const organization = document.getElementById('regOrg').value;
        const role = document.getElementById('regRole').value;
        await this.handleRegister(username, email, password, organization, role);
      });
    }

    // Demo Quick-Login Buttons
    const btnDemoGarima = document.getElementById('btnDemoGarima');
    if (btnDemoGarima) {
      btnDemoGarima.addEventListener('click', async () => {
        await this.handleLogin('garima.zero', 'zero2026');
      });
    }

    const btnDemoAdmin = document.getElementById('btnDemoAdmin');
    if (btnDemoAdmin) {
      btnDemoAdmin.addEventListener('click', async () => {
        await this.handleLogin('admin', 'admin123');
      });
    }

    // Logout Button
    const btnLogout = document.getElementById('btnLogout');
    if (btnLogout) {
      btnLogout.addEventListener('click', () => this.handleLogout());
    }

    // Dropzone & File Upload
    const dropzone = document.getElementById('datasetDropzone');
    const fileInput = document.getElementById('fileDatasetInput');

    if (dropzone && fileInput) {
      dropzone.addEventListener('click', () => fileInput.click());

      dropzone.addEventListener('dragover', (e) => {
        e.preventDefault();
        dropzone.classList.add('dragover');
      });

      dropzone.addEventListener('dragleave', () => dropzone.classList.remove('dragover'));

      dropzone.addEventListener('drop', (e) => {
        e.preventDefault();
        dropzone.classList.remove('dragover');
        if (e.dataTransfer.files.length) {
          this.uploadFile(e.dataTransfer.files[0]);
        }
      });

      fileInput.addEventListener('change', () => {
        if (fileInput.files.length) {
          this.uploadFile(fileInput.files[0]);
        }
      });
    }

    // Load Pre-built Sample Button
    const btnLoadSample = document.getElementById('btnLoadSampleDataset');
    if (btnLoadSample) {
      btnLoadSample.addEventListener('click', () => this.loadSampleDataset());
    }
  }

  async handleLogin(username, password) {
    try {
      const res = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Login failed');

      this.currentUser = data.user;
      localStorage.setItem('sentinel_user', JSON.stringify(this.currentUser));
      this.updateUserUI();
      this.loadDatasets();
      alert(`Welcome back, ${this.currentUser.username} (${this.currentUser.organization})`);
    } catch (err) {
      alert(`Authentication Error: ${err.message}`);
    }
  }

  async handleRegister(username, email, password, organization, role) {
    try {
      const res = await fetch('/api/auth/register', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, email, password, organization, role })
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Registration failed');

      this.currentUser = data.user;
      localStorage.setItem('sentinel_user', JSON.stringify(this.currentUser));
      this.updateUserUI();
      this.loadDatasets();
      alert(`Registration Successful! Welcome to BitSentinel AI, ${this.currentUser.username}`);
    } catch (err) {
      alert(`Registration Error: ${err.message}`);
    }
  }

  handleLogout() {
    this.currentUser = null;
    localStorage.removeItem('sentinel_user');
    this.updateUserUI();
    this.loadDatasets();
  }

  updateUserUI() {
    const authBox = document.getElementById('adminAuthBox');
    const profileBox = document.getElementById('adminProfileBox');

    if (this.currentUser) {
      if (authBox) authBox.style.display = 'none';
      if (profileBox) {
        profileBox.style.display = 'block';
        document.getElementById('profileUsername').textContent = this.currentUser.username;
        document.getElementById('profileOrg').textContent = this.currentUser.organization;
        document.getElementById('profileRole').textContent = this.currentUser.role;
      }
    } else {
      if (authBox) authBox.style.display = 'block';
      if (profileBox) profileBox.style.display = 'none';
    }
  }

  async uploadFile(file) {
    const uploadStatus = document.getElementById('uploadProgressStatus');
    if (uploadStatus) {
      uploadStatus.style.display = 'block';
      uploadStatus.innerHTML = `
        <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--neon-cyan); margin-bottom: 8px;">
          SCANNING DATASET: "${file.name}" with BitSentinel ML Ensemble...
        </div>
        <div class="feature-progress-track">
          <div class="feature-progress-fill" style="width: 100%; animation: pulseGreen 1s infinite;"></div>
        </div>
      `;
    }

    const formData = new FormData();
    formData.append('file', file);
    formData.append('user_id', this.currentUser ? this.currentUser.id : 1);

    try {
      const res = await fetch('/api/admin/upload-dataset', {
        method: 'POST',
        body: formData
      });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Upload failed');

      if (uploadStatus) {
        uploadStatus.innerHTML = `
          <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--safe-green); padding: 8px; background: rgba(16, 185, 129, 0.1); border-radius: 6px;">
            AI ANALYSIS COMPLETE: ${data.total_processed} transactions scanned! Anomalies: ${data.summary.anomalies_count} | High Risk: ${data.summary.high_risk_count}
          </div>
        `;
      }

      this.loadDatasets();
      this.viewDatasetDetail(data.dataset_id);
    } catch (err) {
      if (uploadStatus) {
        uploadStatus.innerHTML = `<div style="color: var(--danger-red); font-size: 0.8rem;">Upload Failed: ${err.message}</div>`;
      }
    }
  }

  async loadSampleDataset() {
    const uploadStatus = document.getElementById('uploadProgressStatus');
    if (uploadStatus) {
      uploadStatus.style.display = 'block';
      uploadStatus.innerHTML = `
        <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--btc-gold); margin-bottom: 8px;">
          LOADING ENTERPRISE BITCOIN SAMPLE DATASET...
        </div>
      `;
    }

    try {
      const userId = this.currentUser ? this.currentUser.id : 1;
      const res = await fetch(`/api/admin/load-sample?user_id=${userId}`, { method: 'POST' });
      const data = await res.json();
      if (!res.ok) throw new Error(data.detail || 'Failed to load sample');

      if (uploadStatus) {
        uploadStatus.innerHTML = `
          <div style="font-family: var(--font-mono); font-size: 0.8rem; color: var(--safe-green); padding: 8px; background: rgba(16, 185, 129, 0.1); border-radius: 6px;">
            ENTERPRISE SAMPLE LOADED: ${data.summary.total_records} transactions analyzed! Found ${data.summary.anomalies_count} anomalies.
          </div>
        `;
      }

      this.loadDatasets();
      this.viewDatasetDetail(data.dataset_id);
    } catch (err) {
      if (uploadStatus) {
        uploadStatus.innerHTML = `<div style="color: var(--danger-red); font-size: 0.8rem;">Error: ${err.message}</div>`;
      }
    }
  }

  async loadDatasets() {
    try {
      const res = await fetch('/api/admin/datasets');
      const data = await res.json();
      this.datasets = data.datasets || [];
      this.renderDatasetsTable();
    } catch (err) {
      console.error('Error fetching datasets', err);
    }
  }

  renderDatasetsTable() {
    const tbody = document.getElementById('datasetsTableBody');
    if (!tbody) return;

    if (this.datasets.length === 0) {
      tbody.innerHTML = `<tr><td colspan="7" style="text-align: center; color: #64748b; padding: 20px;">No organization datasets uploaded yet. Upload a CSV/JSON or click 'Load Sample'.</td></tr>`;
      return;
    }

    tbody.innerHTML = this.datasets.map(ds => {
      return `
        <tr>
          <td><strong style="color: var(--neon-cyan);">${ds.filename}</strong></td>
          <td><span class="panel-title-badge">${ds.file_type}</span></td>
          <td>${ds.row_count} Txs</td>
          <td><span style="color: ${ds.anomalies_detected > 0 ? 'var(--danger-red)' : 'var(--safe-green)'}; font-weight: 700;">${ds.anomalies_detected}</span></td>
          <td><span class="risk-badge ${ds.high_risk_ratio > 20 ? 'critical' : ds.high_risk_ratio > 5 ? 'high' : 'low'}">${ds.high_risk_ratio}%</span></td>
          <td><span style="color: #64748b; font-size: 0.72rem;">${ds.uploaded_at.substring(0, 19).replace('T', ' ')}</span></td>
          <td>
            <div style="display: flex; gap: 6px;">
              <button class="cyber-btn-sm" onclick="window.adminManager.viewDatasetDetail(${ds.id})">VIEW</button>
              <a class="cyber-btn-sm" style="text-decoration: none;" href="/api/admin/datasets/${ds.id}/export" target="_blank">AUDIT</a>
              <button class="btn-danger" onclick="window.adminManager.deleteDataset(${ds.id})">DEL</button>
            </div>
          </td>
        </tr>
      `;
    }).join('');
  }

  async viewDatasetDetail(datasetId) {
    this.activeDatasetId = datasetId;
    try {
      const res = await fetch(`/api/admin/datasets/${datasetId}`);
      const data = await res.json();
      
      const viewer = document.getElementById('datasetDetailViewer');
      if (!viewer) return;

      viewer.style.display = 'block';
      document.getElementById('viewDsTitle').textContent = `Dataset Audit: ${data.dataset.filename}`;
      document.getElementById('viewDsCount').textContent = `${data.dataset.row_count} Records`;
      document.getElementById('viewDsAnomalies').textContent = `${data.dataset.anomalies_detected} Flagged`;
      document.getElementById('viewDsRiskRatio').textContent = `${data.dataset.high_risk_ratio}% High Risk`;

      const txTbody = document.getElementById('viewDsTxTableBody');
      if (txTbody) {
        txTbody.innerHTML = data.transactions.map(tx => {
          return `
            <tr>
              <td><span style="color: #64748b;">${tx.timestamp}</span></td>
              <td><span class="hash-link" title="${tx.tx_hash}">${tx.tx_hash.substring(0, 10)}...</span></td>
              <td style="color: var(--btc-gold); font-weight: 700;">${tx.amount_btc.toFixed(4)} BTC</td>
              <td>$${tx.amount_usd.toLocaleString()}</td>
              <td><span class="risk-badge ${tx.risk_level.toLowerCase()}">${tx.risk_level} (${tx.risk_score})</span></td>
              <td><span style="font-size: 0.72rem; color: #cbd5e1;">${tx.anomaly_tags}</span></td>
            </tr>
          `;
        }).join('');
      }

      // Scroll into view
      viewer.scrollIntoView({ behavior: 'smooth' });
    } catch (err) {
      alert(`Error loading dataset details: ${err.message}`);
    }
  }

  async deleteDataset(datasetId) {
    if (!confirm('Are you sure you want to delete this dataset and its analysis audit records?')) return;
    try {
      const res = await fetch(`/api/admin/datasets/${datasetId}`, { method: 'DELETE' });
      if (res.ok) {
        this.loadDatasets();
        const viewer = document.getElementById('datasetDetailViewer');
        if (viewer && this.activeDatasetId === datasetId) {
          viewer.style.display = 'none';
        }
      }
    } catch (err) {
      alert('Failed to delete dataset');
    }
  }
}

window.AdminPortalManager = AdminPortalManager;
