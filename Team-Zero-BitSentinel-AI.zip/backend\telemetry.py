"""
BitSentinel AI - Live Bitcoin Telemetry & Stream Generator
Produces real-time transaction traffic, mempool metrics, and time-series telemetry.
"""

import time
import random
import hashlib
from datetime import datetime, timedelta
from .ml_engine import detector

SAMPLE_POOLS = [
    {"source": "1P5ZEDWTKTFGxQjZphgWPQUpe554WKDfHQ", "dest": "3J98t1WpEZ73CNmQviecrnyiWrnqRhWNLy", "entity": "Institutional Liquidity Transfer"},
    {"source": "bc1qa5wkgaew2dkv56kfvj49j0av5nml45x9ek9hz6", "dest": "1BoatSLRHtKNngkdXEeobR76b53LETtpyT", "entity": "Hydra Obfuscation Funnel", "forced_anomaly": "MIXER"},
    {"source": "1LdRcdxfbSnmCYYNdeYpUnztiYzVfBEQeC", "dest": "bc1q78p2e8e9r93m5x5f6s7a8d9f0g1h2j3k4l5z1", "entity": "Conti Ransomware Hop", "forced_anomaly": "PEELING_CHAIN"},
    {"source": "3FZbgi29cpjq2GjdwV8eyHuJJnkLtktZc5", "dest": "bc1qxy2kgdygjrsqtzq2n0yrf2493p83kkfjhx0wlh", "entity": "Lazarus Sanctioned Hop", "forced_anomaly": "MIXER"},
    {"source": "bc1qm34lsc65zpw79lxes69zkqmk6ee3ewf0j77s3h", "dest": "bc1qar0srrr7xfkvy5l643lydnw9re59gtzzwf5mdq", "entity": "Coinbase Retail Payout"},
    {"source": "bc1q88a9s7d6f5g4h3j2k1l0z9x8c7v6b5n4m3q1", "dest": "34xp4vRoCGJym3xR7yCVPFHoCNxv4Twseo", "entity": "Structuring Mules", "forced_anomaly": "STRUCTURING"},
    {"source": "1CounterpartyXXXXXXXXXXXXXXXUWLpVr", "dest": "1A1zP1eP5QGefi2DMPTfTL5SLmv7DivfNa", "entity": "Micro Dust Probe", "forced_anomaly": "DUST"},
]

def generate_tx_hash():
    seed = f"{time.time()}_{random.random()}"
    return hashlib.sha256(seed.encode()).hexdigest()

def generate_single_transaction(forced_type=None):
    """
    Generates a realistic Bitcoin transaction payload and runs it through the AI anomaly detector.
    """
    tx_hash = generate_tx_hash()
    
    if forced_type:
        pool_item = next((p for p in SAMPLE_POOLS if p.get("forced_anomaly") == forced_type), random.choice(SAMPLE_POOLS))
    else:
        pool_item = random.choice(SAMPLE_POOLS)

    # Values
    forced_anomaly = forced_type or pool_item.get("forced_anomaly", None)
    
    if forced_anomaly == "PEELING_CHAIN":
        amount_btc = round(random.uniform(2.5, 14.0), 4)
        fee_sat_vb = round(random.uniform(45.0, 95.0), 1)
        inputs_count = 1
        outputs_count = 2
        change_ratio = round(random.uniform(0.91, 0.96), 2)
        equal_outputs = False
    elif forced_anomaly == "MIXER":
        amount_btc = round(random.uniform(0.5, 8.0), 4)
        fee_sat_vb = round(random.uniform(65.0, 160.0), 1)
        inputs_count = random.randint(4, 8)
        outputs_count = random.randint(4, 8)
        change_ratio = 0.5
        equal_outputs = True
    elif forced_anomaly == "STRUCTURING":
        amount_btc = round(random.uniform(0.142, 0.145), 4) # ~$9,700 - $9,950
        fee_sat_vb = round(random.uniform(20.0, 45.0), 1)
        inputs_count = 1
        outputs_count = 2
        change_ratio = 0.8
        equal_outputs = False
    elif forced_anomaly == "DUST":
        amount_btc = 0.000085
        fee_sat_vb = round(random.uniform(15.0, 30.0), 1)
        inputs_count = 1
        outputs_count = 20
        change_ratio = 0.0
        equal_outputs = False
    else:
        # Standard benign traffic
        amount_btc = round(random.uniform(0.005, 3.2), 4)
        fee_sat_vb = round(random.uniform(12.0, 38.0), 1)
        inputs_count = random.choice([1, 2])
        outputs_count = random.choice([2, 3])
        change_ratio = round(random.uniform(0.3, 0.8), 2)
        equal_outputs = False

    raw_tx = {
        "tx_hash": tx_hash,
        "source_address": pool_item["source"],
        "dest_address": pool_item["dest"],
        "amount_btc": amount_btc,
        "fee_sat_vb": fee_sat_vb,
        "inputs_count": inputs_count,
        "outputs_count": outputs_count,
        "change_ratio": change_ratio,
        "equal_outputs": equal_outputs,
        "forced_anomaly": forced_anomaly,
        "timestamp": datetime.utcnow().strftime("%H:%M:%S")
    }

    analysis = detector.analyze_transaction(raw_tx)

    return {
        **raw_tx,
        **analysis,
        "confirmations": random.choice([0, 0, 1, 2, 4]),
        "size_vbytes": inputs_count * 68 + outputs_count * 31 + 10
    }

def get_telemetry_snapshot():
    """
    Returns high-level system telemetry for the HUD KPI counters.
    """
    now = datetime.utcnow()
    return {
        "network": "Bitcoin Mainnet v28.0 Core",
        "timestamp": now.isoformat(),
        "tps": round(random.uniform(6.8, 11.4), 2),
        "mempool_tx_count": random.randint(184200, 198500),
        "mempool_vsize_mb": round(random.uniform(142.5, 168.2), 2),
        "fastest_fee_sat_vb": random.randint(32, 45),
        "economy_fee_sat_vb": random.randint(15, 22),
        "block_height": 884920,
        "hash_rate_ehs": round(random.uniform(635.0, 685.0), 1),
        "btc_price_usd": detector.btc_price,
        "total_flagged_24h": random.randint(1420, 1590),
        "threat_status": "ELEVATED DEFENSE",
        "threat_index": 68.4
    }

def get_chart_series():
    """
    Generates time-series data for front-end charts:
    - Volume velocity (last 12 hours)
    - Fee rate distribution
    - Anomaly category counts
    """
    labels = []
    volume_data = []
    anomaly_data = []
    now = datetime.utcnow()

    for i in range(12, -1, -1):
        t = now - timedelta(hours=i)
        labels.append(t.strftime("%H:00"))
        volume_data.append(round(random.uniform(1800.0, 4200.0), 1))
        anomaly_data.append(random.randint(45, 140))

    risk_distribution = {
        "Low Risk": 74.2,
        "Medium Risk": 16.5,
        "High Risk": 6.8,
        "Critical Threat": 2.5
    }

    anomaly_types = {
        "Peeling Chain": 412,
        "CoinJoin / Tumbler": 328,
        "AML Smurfing": 285,
        "Sanctioned Entity": 98,
        "Dusting Attacks": 142
    }

    return {
        "labels": labels,
        "volume_series": volume_data,
        "anomaly_series": anomaly_data,
        "risk_distribution": risk_distribution,
        "anomaly_types": anomaly_types
    }
